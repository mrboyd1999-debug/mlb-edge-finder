/**
 * Verified-play pass/fail audit with categorized failure breakdown.
 */

import {
  passesVerifiedBestPlaysFilter,
  passesResearchBestPlaysFilter,
} from "./bestPlaysPipelineDebug.js";
import {
  auditVerificationFailure,
  summarizeVerificationAudit,
  logTopPickScoreAudit,
  logVerificationRegressionAudit,
  resolveVerifiedMetrics,
  VERIFIED_BASE_MIN_PROBABILITY,
  VERIFIED_BASE_MIN_CONFIDENCE,
  VERIFIED_MIN_DATA_QUALITY,
  VERIFIED_TIER_B,
  hasIncompleteSupportingData,
  classifyVerifiedTier,
  explainVerificationRejection,
  passesVerifiedTierFilter,
  countVerifiedTierDistribution,
  VERIFICATION_AUDIT_KEYS,
} from "./verifiedTierSystem.js";
import {
  annotateTopPickRankingFields,
  compareTopPickScore,
  compareVerifiedPlaysRank,
  passesTopVerifiedPlaysGate,
  resolvePlayabilityScore,
} from "./bestPlayRankingScore.js";
import { TIER_C_MIN_SANITY_SCORE, resolveHistoricalDataPresent } from "./tierHistoricalValidation.js";
import {
  computeStandardEdge,
  computeStandardEdgePercent,
} from "./standardPropMetrics.js";
import { resolveProjectionValue, hasMajorResearchGaps, isLowMatchupProp } from "./conservativeProjection.js";
import { buildProbabilityDistributionAudit,
  resolveProbabilityPipelineValues,
} from "./probabilityDistributionAudit.js";
import { buildProjectionSanityAudit } from "./projectionSanityAudit.js";
import { enrichBestPlayRankingFields } from "./bestPlayRanking.js";
import { logProbabilityEngineSummary } from "./probabilityEngineAudit.js";
import { computePlayabilityBreakdown } from "./playabilityScoring.js";
import {
  buildTopVerifiedScoringAuditRows,
  detectScoreClonePatterns,
} from "./scoringPrecisionAudit.js";
import {
  attachHistoricalStatsToProps,
  buildHistoricalCoverageAudit,
} from "./historicalStatsLoader.js";
import { resolveEngineProjectedPool } from "./projectionPipelineStatus.js";

export { PROBABILITY_HISTOGRAM_BUCKETS } from "./probabilityDistributionAudit.js";

export { VERIFICATION_AUDIT_KEYS };

export const DIAGNOSTIC_TOP_N = 10;
export const DIAGNOSTIC_PROJECTED_TOP_N = 20;

function emptyBreakdown() {
  return {
    failedProjection: 0,
    failedProbability: 0,
    failedConfidence: 0,
    failedMatchup: 0,
    failedDataQuality: 0,
  };
}

export const AUDIT_LABELS = {
  failedProjection: "Failed Projection",
  failedProbability: "Failed Probability",
  failedConfidence: "Failed Confidence",
  failedMatchup: "Failed Matchup",
  failedDataQuality: "Failed Data Quality",
};

export const VERIFICATION_FAILURE_GATE_ORDER = [
  "failedProbability",
  "failedConfidence",
  "failedPlayability",
  "failedSanity",
  "failedTierGate",
];

export const VERIFICATION_FAILURE_GATE_LABELS = {
  totalProps: "Total Props",
  propsWithProjections: "Projected Props",
  verifiedPlays: "Verified Props",
  propsMissingHistoricalData: "Props Missing Historical Data",
  propsUsingNeutralHistoricalFallback: "Props Using Neutral Historical Fallback",
  historicalDataCoveragePercent: "Historical Data Coverage %",
  projected: "Projected Props",
  passedProbability: "Passed Probability",
  failedProbability: "Failed Probability",
  passedConfidence: "Passed Confidence",
  failedConfidence: "Failed Confidence",
  passedPlayability: "Passed Playability",
  failedPlayability: "Failed Playability",
  passedSanity: "Passed Sanity",
  failedSanity: "Failed Sanity",
  passedTierGate: "Passed Tier Gate",
  failedTierGate: "Failed Tier Gate",
};

function resolveBreakdownSanityScore(prop = {}, metrics = {}) {
  const direct = Number(prop.projectionSanityScore ?? prop.projectionSanityAudit?.sanityScore);
  if (Number.isFinite(direct)) return Math.round(direct);
  if (metrics.sanity != null && Number.isFinite(metrics.sanity)) return Math.round(metrics.sanity);
  return null;
}

export function resolveVerificationWaterfallRejection(prop = {}, metrics = null) {
  const resolvedMetrics = metrics || resolveVerifiedMetrics(prop);

  if (failsProbabilityGate(resolvedMetrics)) {
    const value = resolvedMetrics.probability;
    return Number.isFinite(value)
      ? `Failed Probability (${Math.round(value)}% below ${VERIFIED_BASE_MIN_PROBABILITY}% floor)`
      : "Failed Probability (missing)";
  }
  if (failsConfidenceGate(resolvedMetrics)) {
    const value = resolvedMetrics.confidence;
    return Number.isFinite(value)
      ? `Failed Confidence (${Math.round(value)}% below ${VERIFIED_BASE_MIN_CONFIDENCE}% floor)`
      : "Failed Confidence (missing)";
  }
  if (failsPlayabilityGate(resolvedMetrics)) {
    const value = resolvedMetrics.playability;
    return Number.isFinite(value)
      ? `Failed Playability (${Math.round(value)} below ${VERIFIED_TIER_B.minPlayability} floor)`
      : "Failed Playability (missing)";
  }
  if (failsSanityGate(prop, resolvedMetrics)) {
    const sanity = resolveBreakdownSanityScore(prop, resolvedMetrics);
    if (prop.projectionSanityAudit?.sanityFail || prop.projectionSanityFail) {
      return prop.projectionSanityAudit?.sanityFailReason || "Failed Sanity (projection cap exceeded)";
    }
    return sanity != null
      ? `Failed Sanity (${sanity} below ${TIER_C_MIN_SANITY_SCORE} floor)`
      : "Failed Sanity";
  }
  if (failsTierGate(prop)) {
    try {
      return explainVerificationRejection(prop) || "Failed Tier Gate";
    } catch {
      return "Failed Tier Gate";
    }
  }
  if (passesVerifiedTierFilter(prop) && !passesTopVerifiedPlaysGate(prop)) {
    return "Blocked by display ranking gate (playability/confidence/research-only)";
  }
  return "Eligible";
}

function buildPlayabilityAuditRow(prop = {}, { withRejection = false } = {}) {
  const enriched = prop?.playabilityBreakdown ? prop : enrichBestPlayRankingFields(prop);
  const breakdown =
    enriched.playabilityBreakdown ??
    computePlayabilityBreakdown(enriched, {
      confidence: enriched.displayConfidenceScore ?? enriched.confidenceScore ?? enriched.confidence,
      probability: enriched.probabilityScore ?? enriched.verifiedProbability,
      sanityAudit: enriched.projectionSanityAudit,
      metrics: {
        edge: enriched.edge,
        edgePercent: enriched.edgePercent,
        probabilityScore: enriched.probabilityScore,
      },
    });

  return {
    player: String(enriched.playerName || enriched.player || "Unknown").trim() || "Unknown",
    market: String(enriched.statType || enriched.market || enriched.propType || "N/A").trim() || "N/A",
    probability: breakdown.probability,
    confidence: breakdown.confidence,
    historicalComponent: breakdown.historicalComponent,
    trendComponent: breakdown.trendComponent,
    projectionComponent: breakdown.projectionComponent,
    penaltyComponent: breakdown.penaltyComponent,
    finalPlayability: breakdown.finalPlayability,
    playability: breakdown.finalPlayability,
    sanity: resolveBreakdownSanityScore(enriched, resolveVerifiedMetrics(enriched)),
    reasonRejected: withRejection ? resolveVerificationWaterfallRejection(enriched) : undefined,
    score: Number(enriched.topPickScore ?? 0).toFixed(1),
  };
}

export function buildRejectedPlayabilityAudits(projectedPool = []) {
  const rows = [];
  for (const prop of projectedPool || []) {
    const enriched = enrichBestPlayRankingFields(prop);
    if (passesVerifiedTierFilter(enriched)) continue;
    rows.push(buildPlayabilityAuditRow(enriched, { withRejection: true }));
  }
  return rows.sort((a, b) => Number(b.score) - Number(a.score));
}

export function buildTopConfidenceProps(projectedPool = [], limit = 10) {
  return [...(projectedPool || [])]
    .map((prop) => buildPlayabilityAuditRow(prop))
    .sort(
      (a, b) =>
        (b.confidence ?? 0) - (a.confidence ?? 0) ||
        (b.finalPlayability ?? 0) - (a.finalPlayability ?? 0)
    )
    .slice(0, limit);
}

export function buildTopPlayabilityProps(projectedPool = [], limit = 10) {
  return [...(projectedPool || [])]
    .map((prop) => buildPlayabilityAuditRow(prop))
    .sort(
      (a, b) =>
        (b.finalPlayability ?? 0) - (a.finalPlayability ?? 0) ||
        (b.confidence ?? 0) - (a.confidence ?? 0)
    )
    .slice(0, limit);
}

export function logRejectedPlayabilityAudits(rows = []) {
  if (!rows.length) return rows;
  console.info("[MLB Pipeline] rejected prop playability audit", { count: rows.length });
  rows.forEach((row) => {
    console.info("[PlayabilityAudit]", row);
  });
  return rows;
}

function buildHighestScoringRejectedProp(projectedPool = []) {
  const rejected = buildRejectedPlayabilityAudits(projectedPool);
  return rejected[0] || null;
}

function failsProbabilityGate(metrics = {}) {
  const { probability } = metrics;
  return !Number.isFinite(probability) || probability < VERIFIED_BASE_MIN_PROBABILITY;
}

function failsConfidenceGate(metrics = {}) {
  const { confidence } = metrics;
  return !Number.isFinite(confidence) || confidence < VERIFIED_BASE_MIN_CONFIDENCE;
}

function failsPlayabilityGate(metrics = {}) {
  const { playability } = metrics;
  return !Number.isFinite(playability) || playability < VERIFIED_TIER_B.minPlayability;
}

function failsSanityGate(prop = {}, metrics = {}) {
  const audit = prop.projectionSanityAudit;
  if (audit?.sanityFail || prop.projectionSanityFail) return true;
  const { sanity } = metrics;
  return sanity != null && sanity < TIER_C_MIN_SANITY_SCORE;
}

export function buildTopVerifiedPlaysRows(projectedPool = [], limit = 20) {
  return buildTopVerifiedScoringAuditRows(projectedPool, limit);
}

function countHistoricalDiagnostics(projectedPool = []) {
  let propsMissingHistoricalData = 0;
  let propsUsingNeutralHistoricalFallback = 0;

  for (const prop of projectedPool || []) {
    const historical = resolveHistoricalDataPresent(prop);
    if (!historical.present) {
      propsMissingHistoricalData += 1;
      propsUsingNeutralHistoricalFallback += 1;
      continue;
    }
    if (prop.historicalStatsAttached || prop.hasGameLogs) continue;
    if (!historical.last5Present || !historical.last10Present || !historical.seasonPresent) {
      propsUsingNeutralHistoricalFallback += 1;
    }
  }

  return { propsMissingHistoricalData, propsUsingNeutralHistoricalFallback };
}

function failsTierGate(prop = {}) {
  return !passesVerifiedTierFilter(prop);
}

/** Sequential waterfall — each prop counts toward the first gate it fails. */
export function buildVerificationFailureBreakdown(projectedPool = [], options = {}) {
  const breakdown = {
    totalProps: Number(options.totalProps ?? projectedPool.length),
    propsWithProjections: projectedPool.length,
    projected: projectedPool.length,
    verifiedPlays: Number(options.verifiedDisplayCount ?? 0),
    verifiedTierCount: Number(options.verifiedTierCount ?? 0),
    passedProbability: 0,
    failedProbability: 0,
    passedConfidence: 0,
    failedConfidence: 0,
    passedPlayability: 0,
    failedPlayability: 0,
    passedSanity: 0,
    failedSanity: 0,
    passedTierGate: 0,
    failedTierGate: 0,
    tierA: 0,
    tierB: 0,
    tierC: 0,
    tierD: 0,
    propsMissingHistoricalData: 0,
    propsUsingNeutralHistoricalFallback: 0,
    verifiedDisplayCount: Number(options.verifiedDisplayCount ?? 0),
    blockedByDisplayRankingGate: 0,
    primaryBottleneck: null,
    primaryBottleneckCount: 0,
    highestScoringRejectedProp: null,
  };

  for (const prop of projectedPool || []) {
    const metrics = resolveVerifiedMetrics(prop);

    if (failsProbabilityGate(metrics)) {
      breakdown.failedProbability += 1;
      continue;
    }
    breakdown.passedProbability += 1;

    if (failsConfidenceGate(metrics)) {
      breakdown.failedConfidence += 1;
      continue;
    }
    breakdown.passedConfidence += 1;

    if (failsPlayabilityGate(metrics)) {
      breakdown.failedPlayability += 1;
      continue;
    }
    breakdown.passedPlayability += 1;

    if (failsSanityGate(prop, metrics)) {
      breakdown.failedSanity += 1;
      continue;
    }
    breakdown.passedSanity += 1;

    if (failsTierGate(prop)) {
      breakdown.failedTierGate += 1;
      continue;
    }
    breakdown.passedTierGate += 1;
  }

  const historicalDiagnostics = countHistoricalDiagnostics(projectedPool);
  breakdown.propsMissingHistoricalData = historicalDiagnostics.propsMissingHistoricalData;
  breakdown.propsUsingNeutralHistoricalFallback =
    historicalDiagnostics.propsUsingNeutralHistoricalFallback;
  breakdown.historicalDataCoveragePercent = options.historicalCoverageAudit?.coveragePercent ?? 0;

  if (breakdown.passedTierGate > 0) {
    breakdown.blockedByDisplayRankingGate = projectedPool.filter(
      (prop) => passesVerifiedTierFilter(prop) && !passesTopVerifiedPlaysGate(prop)
    ).length;
  }

  const failureCounts = VERIFICATION_FAILURE_GATE_ORDER.map((key) => ({
    key,
    label: VERIFICATION_FAILURE_GATE_LABELS[key],
    count: breakdown[key] ?? 0,
  })).sort((a, b) => b.count - a.count);

  const top = failureCounts[0];
  if (top?.count > 0) {
    breakdown.primaryBottleneck = top.label;
    breakdown.primaryBottleneckCount = top.count;
  }

  breakdown.verifiedTierCount = breakdown.passedTierGate;
  const tierDistribution = countVerifiedTierDistribution(
    (projectedPool || []).filter(passesVerifiedTierFilter)
  );
  breakdown.tierA = tierDistribution.tierA;
  breakdown.tierB = tierDistribution.tierB;
  breakdown.tierC = tierDistribution.tierC;
  breakdown.tierD = tierDistribution.tierD;
  breakdown.highestScoringRejectedProp = buildHighestScoringRejectedProp(projectedPool);

  return breakdown;
}

export function resolveProjectedPool(props = []) {
  return resolveEngineProjectedPool(props);
}

function annotateHistoricalCoverage(props = []) {
  return (props || []).map((prop) => {
    const historical = resolveHistoricalDataPresent(prop);
    return {
      ...prop,
      historicalCoverage: historical.present,
    };
  });
}

function displayCell(value, suffix = "") {
  if (value == null || value === "") return "N/A";
  if (typeof value === "number" && !Number.isFinite(value)) return "N/A";
  if (value === "N/A") return "N/A";
  return `${value}${suffix}`;
}

function displayMetric(value, { decimals = 0 } = {}) {
  if (value == null || value === "") return "N/A";
  const num = Number(value);
  if (Number.isFinite(num)) {
    return decimals > 0 ? Number(num.toFixed(decimals)) : Math.round(num);
  }
  return String(value);
}

function toVerificationDiagnosticRow(
  prop = {},
  { withFailureReason = false, withMatchup = false, withPropDetails = false } = {}
) {
  const player = String(prop.playerName || prop.player || "Unknown").trim() || "N/A";
  const pipeline = resolveProbabilityPipelineValues(prop);
  const probability = displayMetric(prop.probabilityScore ?? prop.verifiedProbability, { decimals: 1 });
  const probabilityRaw = displayMetric(
    pipeline.calibrated ?? pipeline.statSpecific ?? pipeline.verifiedCapped ?? pipeline.researchCapped,
    { decimals: 1 }
  );
  const confidence = displayMetric(
    prop.displayConfidenceScore ?? prop.confidenceScore ?? prop.confidence
  );
  const playability = displayMetric(prop.playabilityScore);
  const scoreRaw = prop.topPickScore ?? prop.verifiedRankingScore ?? prop.weightedBestPlayScore;
  const score = Number.isFinite(Number(scoreRaw)) ? Number(scoreRaw).toFixed(1) : "N/A";

  const projection = finite(prop.projection ?? prop.projectedValue ?? resolveProjectionValue(prop));
  const line = finite(prop.line);
  const edge = finite(prop.edge ?? computeStandardEdge(projection, line));
  const edgePercent = finite(prop.edgePercent ?? computeStandardEdgePercent(edge, line));

  const calibrationInputs =
    prop.probabilityCalibration?.inputs ||
    prop.probabilityAudit?.calibration?.inputs ||
    pipeline.calibrationInputs ||
    null;

  const row = {
    player,
    probability,
    probabilityRaw,
    confidence,
    playability,
    score,
    last5HitRate: calibrationInputs?.last5HitRate ?? "—",
    last10HitRate: calibrationInputs?.last10HitRate ?? "—",
    seasonHitRate: calibrationInputs?.seasonHitRate ?? "—",
    edgeInput: calibrationInputs?.projectionVsLine ?? "—",
    matchupInput: calibrationInputs?.matchupAdjustment ?? "—",
  };

  if (withPropDetails) {
    row.propType =
      String(prop.statType || prop.market || prop.propType || "N/A").trim() || "N/A";
    row.line = line != null ? line : "N/A";
    row.projection = projection != null ? projection : "N/A";
    row.edge =
      edgePercent != null
        ? `${edgePercent > 0 ? "+" : ""}${Math.round(edgePercent)}%`
        : edge != null
          ? `${edge > 0 ? "+" : ""}${edge}`
          : "N/A";
    row.capFlag = pipeline.likelyLegacyCap ? "legacy_cap_70" : "—";
  }

  if (withFailureReason) {
    try {
      row.failureReason = passesVerifiedTierFilter(prop)
        ? "passed verification"
        : explainVerificationRejection(prop);
    } catch {
      row.failureReason = "N/A";
    }
  }

  if (withMatchup) {
    const matchup = prop.matchupAudit || {};
    row.team = displayCell(matchup.team || prop.team);
    row.opponent = displayCell(matchup.opponent || prop.opponent);
    row.pitcher = displayCell(matchup.pitcher || prop.opposingPitcher || prop.pitcherName);
    row.venue = displayCell(matchup.venue || prop.venue || prop.ballpark || prop.stadium);
    row.matchupScore =
      matchup.matchupScore != null && Number.isFinite(Number(matchup.matchupScore))
        ? Math.round(Number(matchup.matchupScore))
        : "N/A";
  }

  return row;
}

function finite(value) {
  const num = Number(value);
  return Number.isFinite(num) ? num : null;
}

function computeGateMetrics(projectedPool = []) {
  let passedProbability = 0;
  let failedProbability = 0;
  let passedConfidence = 0;
  let failedConfidence = 0;
  let passedDataQuality = 0;
  let failedDataQuality = 0;
  let passedMatchup = 0;
  let failedMatchup = 0;

  for (const prop of projectedPool) {
    const { probability, confidence, dataQuality } = resolveVerifiedMetrics(prop);
    const probPass =
      Number.isFinite(probability) && probability >= VERIFIED_BASE_MIN_PROBABILITY;
    if (probPass) passedProbability += 1;
    else failedProbability += 1;

    const confPass =
      probPass && Number.isFinite(confidence) && confidence >= VERIFIED_BASE_MIN_CONFIDENCE;
    if (probPass) {
      if (confPass) passedConfidence += 1;
      else failedConfidence += 1;
    }

    if (confPass) {
      const dqFail = Number.isFinite(dataQuality) && dataQuality < VERIFIED_MIN_DATA_QUALITY;
      if (dqFail) failedDataQuality += 1;
      else passedDataQuality += 1;
    }

    if (hasIncompleteSupportingData(prop)) failedMatchup += 1;
    else passedMatchup += 1;
  }

  return {
    passedProbability,
    failedProbability,
    passedConfidence,
    failedConfidence,
    passedDataQuality,
    failedDataQuality,
    passedMatchup,
    failedMatchup,
  };
}

function countTierBreakdown(picks = []) {
  return countVerifiedTierDistribution(picks);
}

function resolveMatchupFailureReason(prop = {}) {
  if (isLowMatchupProp(prop)) return "Low matchup confidence";
  if (prop.projectionUnavailable || prop.isFallbackProjection) return "Projection unavailable or fallback";
  if (prop.unverifiedGradeBlocked) return "Unverified grade blocked";
  if (hasMajorResearchGaps(prop)) return "Research gaps / missing supporting data";
  if (!String(prop.opponent || "").trim() && !prop.matchupNote) return "Missing opponent or matchup context";
  return "Incomplete supporting data";
}

function buildMatchupFailureAudit(projectedPool = []) {
  const reasonCounts = {};
  let passedMatchupCount = 0;
  let failedMatchupCount = 0;

  for (const prop of projectedPool || []) {
    if (hasIncompleteSupportingData(prop)) {
      failedMatchupCount += 1;
      const reason = resolveMatchupFailureReason(prop);
      reasonCounts[reason] = (reasonCounts[reason] || 0) + 1;
    } else {
      passedMatchupCount += 1;
    }
  }

  const topFailedMatchupReasons = Object.entries(reasonCounts)
    .sort((a, b) => b[1] - a[1])
    .slice(0, 8)
    .map(([reason, count]) => ({ reason, count }));

  return { passedMatchupCount, failedMatchupCount, topFailedMatchupReasons };
}

function buildProjectionOutlierAudit(projectedPool = []) {
  let projectionOutlierCount = 0;
  let projectionMismatchCount = 0;
  const topProjectionOutliers = [];

  for (const prop of projectedPool || []) {
    const audit = buildProjectionSanityAudit(prop);
    if (audit.projectionMismatch) projectionMismatchCount += 1;
    if (!audit.isOutlier && !audit.projectionMismatch) continue;
    projectionOutlierCount += 1;
    if (topProjectionOutliers.length < 8) {
      topProjectionOutliers.push({
        player: String(prop.playerName || prop.player || "Unknown").trim(),
        market: audit.marketLabel,
        projection: audit.projectionLabel,
        season: audit.seasonLabel,
        sanityScore: audit.sanityScore,
        flag: audit.projectionMismatch ? "ProjectionMismatch" : audit.outlierWarning || "Outlier",
        recentOverRate: audit.recentOverRateLabel,
        projectionProbability: audit.projectionProbabilityLabel,
      });
    }
  }

  return { projectionOutlierCount, projectionMismatchCount, topProjectionOutliers };
}

function buildRuleRejectionCounts(projectedPool = []) {
  const counts = {};
  for (const prop of projectedPool) {
    if (passesVerifiedTierFilter(prop)) continue;
    const rule = auditVerificationFailure(prop) || "failedProbability";
    const label = AUDIT_LABELS[rule] || rule;
    counts[label] = (counts[label] || 0) + 1;
  }
  return counts;
}

function buildTopDiagnosticRows(pool = [], limit = DIAGNOSTIC_TOP_N, options = {}) {
  const rows = [];
  for (const prop of pool || []) {
    try {
      const enriched =
        prop?.topPickScore != null ||
        prop?.probabilityAudit != null ||
        prop?.matchupAudit != null
          ? prop
          : annotateTopPickRankingFields(prop);
      rows.push({ prop: enriched, row: toVerificationDiagnosticRow(enriched, options) });
    } catch (error) {
      rows.push({
        prop,
        row: {
          player: String(prop?.playerName || prop?.player || "Unknown").trim() || "N/A",
          probability: "N/A",
          probabilityRaw: "N/A",
          confidence: "N/A",
          playability: "N/A",
          score: "N/A",
          propType: options.withPropDetails ? "N/A" : undefined,
          line: options.withPropDetails ? "N/A" : undefined,
          projection: options.withPropDetails ? "N/A" : undefined,
          edge: options.withPropDetails ? "N/A" : undefined,
          capFlag: options.withPropDetails ? "—" : undefined,
          failureReason: options.withFailureReason ? "N/A" : undefined,
          team: options.withMatchup ? "N/A" : undefined,
          opponent: options.withMatchup ? "N/A" : undefined,
          pitcher: options.withMatchup ? "N/A" : undefined,
          venue: options.withMatchup ? "N/A" : undefined,
          matchupScore: options.withMatchup ? "N/A" : undefined,
        },
      });
      console.warn("[MLB Pipeline] diagnostic row build failed", {
        player: prop?.playerName || prop?.player,
        error: error?.message || error,
      });
    }
  }

  return rows
    .sort((a, b) => compareTopPickScore(a.prop, b.prop))
    .slice(0, limit)
    .map(({ row }) => row);
}

export function categorizeVerifiedFailure(prop = {}) {
  return auditVerificationFailure(prop) || "failedProbability";
}

export function buildVerificationDashboard(props = [], options = {}) {
  const skipHeavyAudit = Boolean(options.skipHeavyAudit);
  const statsMap = options.statsMap || null;
  const historicalContext = { statsMap, seasonStats: options.seasonStats || [] };

  const rawProps = props || [];
  if (!skipHeavyAudit) console.log("RAW", rawProps.length);

  const projectedPoolRaw =
    options.projectedPool?.length > 0
      ? options.projectedPool
      : resolveProjectedPool(rawProps);
  if (!skipHeavyAudit) console.log("PROJECTED", projectedPoolRaw.length);

  if (skipHeavyAudit) {
    const projectedPool = projectedPoolRaw;
    const verifiedPicks = options.verifiedPicks || [];
    const verifiedCount = verifiedPicks.length;
    const verificationFailureBreakdown = {
      totalProps: Number(options.totalProps ?? rawProps.length),
      propsWithProjections: projectedPool.length,
      projected: projectedPool.length,
      verifiedPlays: verifiedCount,
      verifiedTierCount: verifiedCount,
      historicalDataCoveragePercent: 0,
      propsMissingHistoricalData: 0,
      propsUsingNeutralHistoricalFallback: 0,
    };
    return {
      projected: projectedPool.length,
      projectedCount: projectedPool.length,
      verifiedCount,
      verifiedPasses: verifiedCount,
      researchPasses: 0,
      verifiedFailures: 0,
      usedVerifiedFallback: Boolean(options.usedVerifiedFallback),
      verificationFailureBreakdown,
      historicalCoverageAudit: null,
      rejectedPlayabilityAudits: [],
      topConfidenceProps: [],
      topPlayabilityProps: [],
      topVerifiedPlays: [],
      topProjectedProps: [],
      probabilityDistribution: null,
      scoreCloneAudit: null,
      total: rawProps.length,
      lightweight: true,
    };
  }

  const audit = summarizeVerificationAudit(props);

  const auditedProps = annotateHistoricalCoverage(
    attachHistoricalStatsToProps(projectedPoolRaw, historicalContext)
  );
  console.log("AFTER HISTORICAL AUDIT", auditedProps.length);

  const projectedPool = auditedProps;
  const historicalCoverageAudit = buildHistoricalCoverageAudit(projectedPoolRaw, historicalContext);
  const verifiedPicks = options.verifiedPicks || [];
  const gateMetrics = computeGateMetrics(projectedPool);
  const matchupAudit = buildMatchupFailureAudit(projectedPool);
  const outlierAudit = buildProjectionOutlierAudit(projectedPool);
  const tierQualified = projectedPool.filter(passesVerifiedBestPlaysFilter);
  const tierCounts = countTierBreakdown(tierQualified);
  const verifiedCount = verifiedPicks.length;
  const verifiedPasses = tierQualified.length;
  console.log("AFTER VERIFICATION", verifiedPasses);

  const ruleRejectionCounts = buildRuleRejectionCounts(projectedPool);
  const verificationFailureBreakdown = buildVerificationFailureBreakdown(projectedPool, {
    verifiedDisplayCount: Math.max(verifiedCount, verifiedPasses),
    verifiedTierCount: verifiedPasses,
    totalProps: Number(options.totalProps ?? rawProps.length),
    historicalCoverageAudit,
  });
  const rejectedPlayabilityAudits = logRejectedPlayabilityAudits(
    buildRejectedPlayabilityAudits(projectedPool)
  );
  const topConfidenceProps = buildTopConfidenceProps(projectedPool, 10);
  const topPlayabilityProps = buildTopPlayabilityProps(projectedPool, 10);
  const topVerifiedPlays = buildTopVerifiedScoringAuditRows(projectedPool, 20);
  const scoreCloneAudit = detectScoreClonePatterns(topVerifiedPlays);
  if (scoreCloneAudit.suspects.length) {
    console.warn("[MLB Pipeline] score clone audit", scoreCloneAudit);
  }

  let researchPasses = 0;
  for (const prop of props || []) {
    if (passesVerifiedBestPlaysFilter(prop)) continue;
    if (passesResearchBestPlaysFilter(prop)) researchPasses += 1;
  }

  const failureBreakdown = { ...emptyBreakdown(), ...audit.breakdown };
  const topProjectedProps = buildTopDiagnosticRows(projectedPool, DIAGNOSTIC_PROJECTED_TOP_N, {
    withFailureReason: true,
    withMatchup: true,
    withPropDetails: true,
  });

  const topProjectedPool = projectedPool
    .slice()
    .sort((a, b) => compareTopPickScore(a, b))
    .slice(0, DIAGNOSTIC_PROJECTED_TOP_N);
  const probabilityDistribution = buildProbabilityDistributionAudit(
    projectedPool,
    topProjectedPool
  );

  console.info("[MLB Pipeline] verification top projected props", {
    projectedPool: projectedPool.length,
    topProjectedPropsLength: topProjectedProps.length,
    firstRow: topProjectedProps[0] || null,
  });

  return {
    projected: projectedPool.length,
    projectedCount: projectedPool.length,
    verifiedCount,
    verifiedPasses,
    researchPasses,
    verifiedFailures: audit.totalFailures,
    usedVerifiedFallback: Boolean(options.usedVerifiedFallback),
    ...gateMetrics,
    passedMatchupCount: matchupAudit.passedMatchupCount,
    failedMatchupCount: matchupAudit.failedMatchupCount,
    topFailedMatchupReasons: matchupAudit.topFailedMatchupReasons,
    projectionOutlierCount: outlierAudit.projectionOutlierCount,
    projectionMismatchCount: outlierAudit.projectionMismatchCount,
    topProjectionOutliers: outlierAudit.topProjectionOutliers,
    tierA: tierCounts.tierA,
    tierB: tierCounts.tierB,
    tierC: tierCounts.tierC,
    tierD: tierCounts.tierD,
    topBeforeVerification: buildTopDiagnosticRows(projectedPool),
    topAfterVerification: buildTopDiagnosticRows(verifiedPicks),
    topProjectedProps,
    probabilityDistribution,
    failureBreakdown,
    verificationFailureBreakdown,
    rejectedPlayabilityAudits,
    topConfidenceProps,
    topPlayabilityProps,
    topVerifiedPlays,
    scoreCloneAudit,
    historicalCoverageAudit,
    ruleRejectionCounts,
    rejectionCounts: verifiedPasses === 0 ? ruleRejectionCounts : null,
    regressionReasons: audit.regressionReasons,
    auditLabels: AUDIT_LABELS,
    auditSamples: audit.samples,
    total: (props || []).length,
  };
}

export function logVerificationDashboardAudit(props = [], options = {}) {
  const dashboard = buildVerificationDashboard(props, options);
  const scoreAudit = logTopPickScoreAudit(props);
  const regression = logVerificationRegressionAudit(props);

  console.info("[MLB Pipeline] verification dashboard", {
    projectedCount: dashboard.projectedCount,
    verifiedPasses: dashboard.verifiedPasses,
    verifiedCount: dashboard.verifiedCount,
    topProjectedPropsLength: dashboard.topProjectedProps?.length ?? 0,
    gateMetrics: {
      passedProbability: dashboard.passedProbability,
      failedProbability: dashboard.failedProbability,
      passedConfidence: dashboard.passedConfidence,
      failedConfidence: dashboard.failedConfidence,
      passedDataQuality: dashboard.passedDataQuality,
      failedDataQuality: dashboard.failedDataQuality,
      passedMatchup: dashboard.passedMatchup,
      failedMatchup: dashboard.failedMatchup,
    },
    tierCounts: {
      tierA: dashboard.tierA,
      tierB: dashboard.tierB,
      tierC: dashboard.tierC,
      tierD: dashboard.tierD,
    },
    ruleRejectionCounts: dashboard.ruleRejectionCounts,
    verificationFailureBreakdown: dashboard.verificationFailureBreakdown,
    failureBreakdown: dashboard.failureBreakdown,
    regressionReasons: dashboard.regressionReasons,
  });

  const probabilityEngineSummary = logProbabilityEngineSummary(props, {
    verifiedCount: dashboard.verifiedPasses ?? dashboard.verifiedCount ?? 0,
    failedProbability: dashboard.failedProbability ?? 0,
  });

  return { ...dashboard, scoreAudit, regression, probabilityEngineSummary };
}
