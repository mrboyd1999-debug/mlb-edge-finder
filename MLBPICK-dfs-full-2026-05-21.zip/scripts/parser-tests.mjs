import assert from "node:assert/strict";

function parseJsonEnvelope(text, source) {
  const trimmed = String(text || "").trim();
  if (!trimmed || trimmed.startsWith("<") || /^export\s+default\b/.test(trimmed)) {
    return { ok: false, source, error: `${source} returned non-JSON response`, props: [] };
  }
  try {
    return { ok: true, source, data: JSON.parse(trimmed), props: [] };
  } catch {
    return { ok: false, source, error: `${source} returned non-JSON response`, props: [] };
  }
}

const prizePicks = parseJsonEnvelope(JSON.stringify({ data: [{ id: "pp1", attributes: { line_score: "5.5" } }] }), "PrizePicks");
assert.equal(prizePicks.ok, true);
assert.equal(Array.isArray(prizePicks.data.data), true);

const underdog = parseJsonEnvelope(JSON.stringify({ over_under_lines: [{ id: "ud1", stat_value: "6.5" }] }), "Underdog");
assert.equal(underdog.ok, true);
assert.equal(Array.isArray(underdog.data.over_under_lines), true);

const odds = parseJsonEnvelope(JSON.stringify([{ id: "event1", commence_time: "2099-01-01T00:00:00Z" }]), "The Odds API");
assert.equal(odds.ok, true);
assert.equal(Array.isArray(odds.data), true);

const html = parseJsonEnvelope("<!doctype html><html></html>", "PrizePicks");
assert.equal(html.ok, false);
assert.equal(html.props.length, 0);

const jsSource = parseJsonEnvelope("export default async function handler() {}", "Underdog");
assert.equal(jsSource.ok, false);
assert.equal(jsSource.props.length, 0);

console.log("Parser smoke tests passed.");
