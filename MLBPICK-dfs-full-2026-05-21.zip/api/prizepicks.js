const APIFY_PRIZEPICKS_ACTOR = "zen-studio~prizepicks-player-props";
const PRIZEPICKS_LEAGUE_IDS = [2, 7, 8, 9, 52, 82, 145];

export default async function handler(req, res) {
  setCorsHeaders(res);

  if (req.method === "OPTIONS") {
    return res.status(200).end();
  }

  try {
    const leagueId = req.query?.league_id;
    if (leagueId) {
      return respondWithFetch(res, await fetchPrizePicksLeague(leagueId));
    }

    const merged = { data: [], included: [] };
    const errors = [];
    for (const id of PRIZEPICKS_LEAGUE_IDS) {
      const result = await fetchPrizePicksLeague(id);
      if (!result.ok) {
        errors.push(result.error);
        continue;
      }
      mergeJsonApiPayload(merged, result.data);
    }

    if (!merged.data.length) {
      const message = errors[0] || "PrizePicks returned no projection data.";
      return res.status(200).json({
        ok: false,
        error: true,
        source: "PrizePicks",
        message,
        errorMessage: message,
        htmlError: /non-json|html/i.test(message),
        props: [],
        data: [],
      });
    }

    return res.status(200).json({
      ok: true,
      error: false,
      source: "PrizePicks",
      props: merged.data,
      data: merged,
    });
  } catch (error) {
    return res.status(200).json({
      ok: false,
      error: true,
      source: "PrizePicks",
      message: error.message || "PrizePicks proxy failed.",
      errorMessage: error.message || "PrizePicks proxy failed.",
      props: [],
      data: [],
    });
  }
}

async function fetchPrizePicksLeague(leagueId) {
  const providerUrl = process.env.PRIZEPICKS_PROXY_URL;
  const apifyToken = process.env.APIFY_TOKEN;
  const directUrl = `https://api.prizepicks.com/projections?league_id=${leagueId}&per_page=250&single_stat=true&game_mode=pickem`;
  const url = providerUrl || apifyActorUrl(APIFY_PRIZEPICKS_ACTOR, apifyToken) || directUrl;

  const response = await fetch(url, {
    headers: {
      "User-Agent": "Mozilla/5.0",
      Accept: "application/json",
      origin: "https://app.prizepicks.com",
      referer: "https://app.prizepicks.com/",
    },
  });
  const text = await response.text();
  const contentType = response.headers.get("content-type") || "";
  const parsed = parseJsonOrError(text, "PrizePicks", contentType);

  console.info("[PrizePicks API] upstream", {
    leagueId,
    status: response.status,
    contentType,
    ok: response.ok,
  });

  if (!response.ok || !parsed.ok) {
    return {
      ok: false,
      error: !response.ok
        ? `PrizePicks provider returned status ${response.status} (league ${leagueId}).`
        : parsed.error,
      data: null,
    };
  }

  return { ok: true, data: parsed.data };
}

function respondWithFetch(res, result) {
  if (!result.ok) {
    const message = result.error || "PrizePicks returned non-JSON response";
    return res.status(200).json({
      ok: false,
      error: true,
      source: "PrizePicks",
      message,
      errorMessage: message,
      htmlError: /non-json|html/i.test(message),
      props: [],
      data: [],
      preview: result.preview || "",
    });
  }

  const data = result.data;
  return res.status(200).json({
    ok: true,
    error: false,
    source: "PrizePicks",
    props: Array.isArray(data) ? data : data?.data || [],
    data,
  });
}

function mergeJsonApiPayload(target, payload) {
  if (!payload) return;
  if (Array.isArray(payload)) {
    target.data.push(...payload);
    return;
  }
  if (Array.isArray(payload.data)) target.data.push(...payload.data);
  if (Array.isArray(payload.included)) target.included.push(...payload.included);
}

function parseJsonOrError(text, source, contentType = "") {
  const trimmed = String(text || "").trim();
  const looksHtml =
    trimmed.startsWith("<") ||
    /text\/html/i.test(contentType) ||
    /^export\s+default\b/.test(trimmed) ||
    trimmed.includes("export default async function");
  if (!trimmed || looksHtml) {
    return { ok: false, error: `${source} returned non-JSON response`, preview: trimmed.slice(0, 300) };
  }
  try {
    return { ok: true, data: JSON.parse(trimmed) };
  } catch {
    return { ok: false, error: `${source} returned non-JSON response`, preview: trimmed.slice(0, 300) };
  }
}

function apifyActorUrl(actor, token) {
  if (!token) return "";
  return `https://api.apify.com/v2/acts/${actor}/run-sync-get-dataset-items?token=${encodeURIComponent(token)}`;
}

function setCorsHeaders(res) {
  res.setHeader("Access-Control-Allow-Origin", "*");
  res.setHeader("Access-Control-Allow-Methods", "GET, OPTIONS");
  res.setHeader("Access-Control-Allow-Headers", "Content-Type");
}
