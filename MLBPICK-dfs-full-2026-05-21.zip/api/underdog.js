export default async function handler(req, res) {
  setCorsHeaders(res);

  if (req.method === "OPTIONS") {
    return res.status(200).end();
  }

  try {
    const providerUrl = process.env.UNDERDOG_PROXY_URL;
    const apifyToken = process.env.APIFY_TOKEN;
    const apifyActor = process.env.UNDERDOG_APIFY_ACTOR;
    const url = providerUrl || apifyActorUrl(apifyActor, apifyToken) || "https://api.underdogfantasy.com/beta/v3/over_under_lines";

    const response = await fetch(url, {
      headers: {
        "User-Agent": "Mozilla/5.0",
        Accept: "application/json",
      },
    });
    const text = await response.text();
    const parsed = parseJsonOrError(text, "Underdog");

    console.info("[Underdog API] upstream", {
      status: response.status,
      contentType: response.headers.get("content-type") || "",
      ok: response.ok,
    });

    if (!response.ok || !parsed.ok) {
      return res.status(200).json({
        ok: false,
        error: true,
        source: "Underdog",
        status: response.status,
        message: !response.ok ? `Underdog provider returned status ${response.status}.` : parsed.error,
        errorMessage: !response.ok ? `Underdog provider returned status ${response.status}.` : parsed.error,
        preview: text.slice(0, 300),
        props: [],
        data: [],
      });
    }

    return res.status(200).json({
      ok: true,
      error: false,
      source: "Underdog",
      props: Array.isArray(parsed.data) ? parsed.data : [],
      data: parsed.data,
    });
  } catch (error) {
    return res.status(200).json({
      ok: false,
      error: true,
      source: "Underdog",
      message: error.message || "Underdog proxy failed.",
      errorMessage: error.message || "Underdog proxy failed.",
      props: [],
      data: [],
    });
  }
}

function parseJsonOrError(text, source) {
  const trimmed = String(text || "").trim();
  if (!trimmed || trimmed.startsWith("<") || /^export\s+default\b/.test(trimmed) || trimmed.includes("export default async function")) {
    return { ok: false, error: `${source} returned non-JSON response` };
  }
  try {
    return { ok: true, data: JSON.parse(trimmed) };
  } catch {
    return { ok: false, error: `${source} returned non-JSON response` };
  }
}

function apifyActorUrl(actor, token) {
  if (!actor || !token) return "";
  return `https://api.apify.com/v2/acts/${actor}/run-sync-get-dataset-items?token=${encodeURIComponent(token)}`;
}

function setCorsHeaders(res) {
  res.setHeader("Access-Control-Allow-Origin", "*");
  res.setHeader("Access-Control-Allow-Methods", "GET, OPTIONS");
  res.setHeader("Access-Control-Allow-Headers", "Content-Type");
}
