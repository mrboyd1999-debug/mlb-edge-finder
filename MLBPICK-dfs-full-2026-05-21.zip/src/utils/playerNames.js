/** Normalize DFS player names for cross-source stat matching. */
export function normalizePlayerName(name = "") {
  return String(name || "")
    .normalize("NFD")
    .replace(/[\u0300-\u036f]/g, "")
    .toLowerCase()
    .replace(/\b(jr|sr|ii|iii|iv)\b\.?/gi, "")
    .replace(/['’.`-]/g, "")
    .replace(/[^a-z0-9\s]/g, " ")
    .replace(/\s+/g, " ")
    .trim();
}

export function playerNameTokens(name = "") {
  return normalizePlayerName(name).split(" ").filter((token) => token.length > 1);
}

export function playerNamesMatch(a, b) {
  const left = normalizePlayerName(a);
  const right = normalizePlayerName(b);
  if (!left || !right) return false;
  if (left === right) return true;
  if (left.includes(right) || right.includes(left)) return true;

  const leftTokens = playerNameTokens(left);
  const rightTokens = playerNameTokens(right);
  if (!leftTokens.length || !rightTokens.length) return false;

  const lastLeft = leftTokens[leftTokens.length - 1];
  const lastRight = rightTokens[rightTokens.length - 1];
  const firstLeft = leftTokens[0];
  const firstRight = rightTokens[0];
  if (lastLeft !== lastRight) return false;

  const shared = leftTokens.filter((token) => rightTokens.includes(token)).length;
  const minLen = Math.min(leftTokens.length, rightTokens.length);
  return shared >= Math.max(1, minLen - 1) || (firstLeft[0] === firstRight[0] && lastLeft === lastRight);
}

export function statProfileKey(prop) {
  const stat = String(prop?.statType || "")
    .toLowerCase()
    .replace(/[^a-z0-9]/g, "");
  return [prop?.sport || "", normalizePlayerName(prop?.playerName), stat].filter(Boolean).join("|");
}

/**
 * Resolve a stat profile from a Map keyed by statProfileKey or legacy keys.
 */
export function findStatProfile(statsMap, prop) {
  if (!(statsMap instanceof Map) || !prop) return null;

  const primary = statProfileKey(prop);
  const direct = statsMap.get(primary);
  if (direct && !direct.fallback) return direct;

  let best = null;
  let bestScore = 0;
  const propSport = String(prop.sport || "").toLowerCase();
  const propStat = String(prop.statType || "")
    .toLowerCase()
    .replace(/[^a-z0-9]/g, "");

  statsMap.forEach((profile) => {
    if (!profile || profile.fallback) return;
    const profileSport = String(profile.sport || "").toLowerCase();
    if (propSport && profileSport && profileSport !== propSport) return;
    if (!playerNamesMatch(prop.playerName, profile.playerName)) return;

    const profileStat = String(profile.statType || profile.market || "")
      .toLowerCase()
      .replace(/[^a-z0-9]/g, "");
    const statMatch = !propStat || !profileStat || profileStat === propStat || profileStat.includes(propStat) || propStat.includes(profileStat);
    if (!statMatch) return;

    const score = playerNameTokens(prop.playerName).length + (profile.projectionSource === "player-stats" ? 2 : 1);
    if (score > bestScore) {
      bestScore = score;
      best = profile;
    }
  });

  return best || direct || null;
}
