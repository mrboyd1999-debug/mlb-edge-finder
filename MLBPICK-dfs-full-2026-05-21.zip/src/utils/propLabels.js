import { confidenceTierLabel, propPayoutLabel } from "../services/projectionEngine.js";
import { normalize } from "./formatters.js";

export function canonicalSportFromProp(prop) {
  const league = normalize(prop?.league);
  const sportText = normalize(prop?.sport);
  if (league.includes("wnba") || sportText === "wnba" || sportText.includes("women")) return "WNBA";
  if (
    (league === "nba" || league.includes("nationalbasketballassociation") || sportText === "nba") &&
    !league.includes("wnba") &&
    !sportText.includes("wnba")
  ) {
    return "NBA";
  }
  return prop?.sport || "Other";
}

export function displaySport(propOrSport) {
  if (typeof propOrSport === "string") return propOrSport;
  const canonical = canonicalSportFromProp(propOrSport);
  if (canonical !== "Other") return canonical;
  const sport = propOrSport?.sport || "";
  if (sport === "ATP Tennis" || sport === "WTA Tennis" || sport === "Tennis") return "Tennis";
  return sport || "Sport";
}

export function confidenceTier(prop) {
  const score = Number(prop.confidenceScore || prop.modelSignal?.confidenceScore || 0);
  return confidenceTierLabel(score, prop.riskLevel || "", {
    strongData: prop.strongData,
    verifiedHistory: prop.verifiedHistory,
  });
}

export { propPayoutLabel };

export function isGoblinProp(prop) {
  return Boolean(prop?.verifiedAdjustedOdds) && propPayoutLabel(prop) === "Goblin";
}

export function isDemonProp(prop) {
  return Boolean(prop?.verifiedAdjustedOdds) && propPayoutLabel(prop) === "Demon";
}

export function playerInitials(name = "") {
  const parts = String(name).trim().split(/\s+/).filter(Boolean);
  if (!parts.length) return "?";
  if (parts.length === 1) return parts[0].slice(0, 2).toUpperCase();
  return `${parts[0][0] || ""}${parts[parts.length - 1][0] || ""}`.toUpperCase();
}
