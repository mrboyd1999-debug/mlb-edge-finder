import { normalize } from "./formatters.js";

const MIN_START_BUFFER_MS = 0;
const LOCKED_STATUSES = new Set(["locked", "suspended", "closed", "inactive", "unavailable", "disabled"]);

export function isGameStarted(prop) {
  const start = new Date(prop.startTime).getTime();
  if (!Number.isFinite(start)) return false;
  return start <= Date.now() + MIN_START_BUFFER_MS;
}

export function isLiveProp(prop) {
  const label = normalize(`${prop.league || ""} ${prop.status || ""} ${prop.gameStatus || ""}`);
  return label.includes("live") || label.includes("inprogress");
}

export function isLockedOrSuspended(prop) {
  const status = normalize(prop.status || prop.lineStatus || "");
  return LOCKED_STATUSES.has(status) || status.includes("locked") || status.includes("suspend");
}

export function isSourceUnavailable(prop) {
  return Boolean(prop.unavailable || prop.isUnavailable || normalize(prop.availability) === "unavailable");
}

export function hasWeakMissingTime(prop) {
  const start = new Date(prop.startTime).getTime();
  const missingTime = !Number.isFinite(start);
  const weakData =
    prop.dataQualityBadge?.tone === "weak" ||
    prop.projectionSource === "missing" ||
    Number(prop.dataQualityScore || 0) < 35;
  return missingTime && weakData;
}

export function getStaleFilterReason(prop) {
  if (isSourceUnavailable(prop)) return "source marked unavailable";
  if (isLiveProp(prop)) return "game is live";
  if (isLockedOrSuspended(prop)) return "prop is locked or suspended";
  if (isGameStarted(prop)) return "game already started";
  if (hasWeakMissingTime(prop)) return "missing game time with weak data";
  return "";
}

export function filterStaleProps(props = []) {
  return props.filter((prop) => !getStaleFilterReason(prop));
}

export function labelPartialIfMissingTime(prop) {
  const start = new Date(prop.startTime).getTime();
  if (Number.isFinite(start)) return prop;
  return {
    ...prop,
    partialTimeLabel: true,
    dataQualityBadge: prop.dataQualityBadge || { label: "Partial data", tone: "partial" },
  };
}
