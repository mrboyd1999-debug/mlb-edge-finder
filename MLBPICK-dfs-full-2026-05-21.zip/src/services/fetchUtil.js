const DEFAULT_TTL_MS = 7.5 * 60 * 1000;
const memoryCache = new Map();

function cacheKey(url, init = {}) {
  const method = (init.method || "GET").toUpperCase();
  return `${method}:${url}`;
}

export function clearApiCache() {
  memoryCache.clear();
  try {
    const keys = [];
    for (let i = 0; i < window.localStorage.length; i += 1) {
      const key = window.localStorage.key(i);
      if (key && (key.startsWith("dfs-fetch-cache:") || key === "dfs-prizepicks-last-good-payload")) {
        keys.push(key);
      }
    }
    keys.forEach((key) => window.localStorage.removeItem(key));
  } catch {
    // ignore storage errors
  }
}

export async function cachedFetch(url, init = {}, ttlMs = DEFAULT_TTL_MS) {
  const key = cacheKey(url, init);
  const now = Date.now();
  const cached = memoryCache.get(key);
  if (cached && now - cached.fetchedAt < ttlMs) {
    return cached.clone ? cached.response.clone() : cached.response;
  }

  try {
    const stored = window.localStorage.getItem(`dfs-fetch-cache:${key}`);
    if (stored) {
      const parsed = JSON.parse(stored);
      if (parsed?.body != null && now - parsed.fetchedAt < ttlMs) {
        const response = new Response(parsed.body, {
          status: parsed.status || 200,
          headers: { "content-type": parsed.contentType || "application/json" },
        });
        memoryCache.set(key, { response, fetchedAt: parsed.fetchedAt });
        return response.clone();
      }
    }
  } catch {
    // ignore parse/storage errors
  }

  const response = await fetch(url, init);
  const clone = response.clone();
  const bodyText = await clone.text();

  memoryCache.set(key, {
    response: new Response(bodyText, {
      status: response.status,
      statusText: response.statusText,
      headers: response.headers,
    }),
    fetchedAt: now,
  });

  try {
    window.localStorage.setItem(
      `dfs-fetch-cache:${key}`,
      JSON.stringify({
        body: bodyText,
        status: response.status,
        contentType: response.headers.get("content-type") || "application/json",
        fetchedAt: now,
      })
    );
  } catch {
    // storage full — memory cache still works
  }

  return new Response(bodyText, {
    status: response.status,
    statusText: response.statusText,
    headers: response.headers,
  });
}

export async function fetchJson(url, init = {}, options = {}) {
  const result = await safeJsonFetch(url, options.source || "API", init, options);
  if (!result.ok) {
    throw new Error(result.error || `${options.source || "API"} returned invalid JSON.`);
  }
  return { response: result.response, data: result.data, text: result.text };
}

export async function safeJsonFetch(url, sourceName = "API", init = {}, options = {}) {
  const source = options.source || sourceName || "API";
  const response = await cachedFetch(url, init, options.ttlMs || DEFAULT_TTL_MS);
  const contentType = response.headers.get("content-type") || "";
  const text = await response.text();
  const preview = text.slice(0, 180).replace(/\s+/g, " ").trim();

  console.info(`[DFS Fetch] ${source}`, {
    url,
    status: response.status,
    contentType,
  });

  if (!response.ok) {
    console.warn(`[DFS Fetch] ${source} failed`, {
      url,
      status: response.status,
      contentType,
      preview,
    });
    return {
      ok: false,
      source: sourceName,
      error: `${sourceName} returned status ${response.status}.`,
      props: [],
      response,
      text,
      preview,
    };
  }

  const trimmed = text.trim();
  if (!trimmed) return { ok: true, source: sourceName, data: null, props: [], response, text };

  if (trimmed.startsWith("<")) {
    console.warn(`[DFS Fetch] ${source} returned HTML instead of JSON`, {
      url,
      contentType,
      preview,
    });
    return {
      ok: false,
      source: sourceName,
      error: `${sourceName} returned non-JSON response. Check proxy/API route.`,
      props: [],
      response,
      text,
      preview,
    };
  }

  if (/^export\s+default\b/.test(trimmed) || trimmed.includes("export default async function")) {
    console.warn(`[DFS Fetch] ${source} returned JavaScript instead of JSON`, {
      url,
      contentType,
      preview,
    });
    return {
      ok: false,
      source: sourceName,
      error: `${sourceName} returned non-JSON response. Check proxy/API route.`,
      props: [],
      response,
      text,
      preview,
    };
  }

  try {
    return { ok: true, source: sourceName, data: JSON.parse(trimmed), props: [], response, text };
  } catch (error) {
    console.warn(`[DFS Fetch] ${source} JSON parse failed`, {
      url,
      contentType,
      preview,
      message: error?.message || String(error),
    });
    return {
      ok: false,
      source: sourceName,
      error: `${sourceName} returned non-JSON response. Check proxy/API route.`,
      props: [],
      response,
      text,
      preview,
    };
  }
}

export function getCacheTtlMs() {
  return DEFAULT_TTL_MS;
}
