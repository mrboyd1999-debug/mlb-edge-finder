import PlayerPropCard from "./PlayerPropCard.jsx";
import { computeRankScore } from "../services/projectionEngine.js";
import { styles } from "../theme/styles.js";

function EmptyState({ text }) {
  return <div style={styles.emptyState}>{text}</div>;
}

export default function TopPicksBoard({ label = "Sport", picks = [], loading, onOpen }) {
  const sorted = [...picks]
    .sort((a, b) => computeRankScore(b) - computeRankScore(a))
    .slice(0, 2)
    .map((prop, index) => ({
      ...prop,
      edgeScore: prop.edgeScore ?? prop.edgeRating,
      topTwoReason:
        prop.topTwoReason ||
        `Pick #${index + 1}: rank ${Math.round(computeRankScore(prop))} · ${prop.confidenceScore}% confidence`,
    }));

  return (
    <section style={styles.section}>
      <div style={styles.sectionHeading}>
        <div>
          <p style={styles.eyebrow}>{label}</p>
          <h2 style={styles.sectionTitle}>Top 2 Picks</h2>
        </div>
        <p style={styles.countPill}>{sorted.length}/2</p>
      </div>
      {loading ? (
        <EmptyState text={`Loading ${label} picks…`} />
      ) : sorted.length === 0 ? (
        <EmptyState text={`No active scheduled props found for ${label}. Try Refresh or another category.`} />
      ) : (
        <div style={styles.topPicksList}>
          {sorted.map((prop, index) => (
            <PlayerPropCard key={prop.id} prop={prop} rank={index + 1} onOpen={onOpen} cardStyle={styles.streakCard} />
          ))}
        </div>
      )}
    </section>
  );
}
