import { styles } from "../theme/styles.js";

export default function PropFilters({
  platform,
  setPlatform,
  sport,
  setSport,
  statType,
  setStatType,
  edgeFilter,
  setEdgeFilter,
  platformOptions = [],
  sportOptions = [],
  propTypes = [],
  edgeFilters = [],
}) {
  return (
    <div style={styles.compactPanel}>
      <section style={styles.controls} aria-label="DFS filters">
        <div style={styles.segmentGroup}>
          <span style={styles.controlLabel}>Source</span>
          <div style={styles.segmentRow}>
            {platformOptions.map((option) => (
              <button
                key={option.id}
                type="button"
                style={platform === option.id ? styles.segmentActive : styles.segment}
                onClick={() => setPlatform(option.id)}
                title={option.statusMessage || option.label}
              >
                {option.label}
              </button>
            ))}
          </div>
        </div>
        <label style={styles.selectLabel}>
          Sport
          <select style={styles.select} value={sport} onChange={(e) => setSport(e.target.value)}>
            {sportOptions.map((option) => (
              <option key={option.value} value={option.value}>
                {option.label}
              </option>
            ))}
          </select>
        </label>
        <label style={styles.selectLabel}>
          Prop type
          <select style={styles.select} value={statType} onChange={(e) => setStatType(e.target.value)}>
            {propTypes.map((option) => (
              <option key={option} value={option}>
                {option === "all" ? "All types" : option}
              </option>
            ))}
          </select>
        </label>
      </section>
      <section style={styles.quickFilters} aria-label="Edge filters">
        <span style={styles.controlLabel}>Edge</span>
        <div style={styles.segmentRow}>
          {edgeFilters.map((option) => (
            <button
              key={option.id}
              type="button"
              style={edgeFilter === option.id ? styles.segmentActive : styles.segment}
              onClick={() => setEdgeFilter(option.id)}
            >
              {option.label}
            </button>
          ))}
        </div>
      </section>
    </div>
  );
}
