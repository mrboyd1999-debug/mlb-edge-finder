import PlayerImage from "./PlayerImage.jsx";
import DataQualityBadge from "./DataQualityBadge.jsx";
import { formatLeanSide, formatNumber, shortReason } from "../utils/formatters.js";
import { confidenceTier, displaySport } from "../utils/propLabels.js";
import { lineMovementArrow, resultStatusBadge, sportsbookCardTag } from "../utils/cardSignals.js";
import { styles, tierStyle } from "../theme/styles.js";

export default function PlayerPropCard({ prop, onOpen, rank, compact = false, cardStyle, savedResult }) {
  const tier = confidenceTier(prop);
  const lean = formatLeanSide(prop.bestPick || prop.side || "Watch");
  const isWatch = prop.recommendationStatus === "watchlist";
  const movementLabel = lineMovementArrow(prop);
  const bookTag = sportsbookCardTag(prop);
  const resultBadge = savedResult ? resultStatusBadge(savedResult) : null;

  return (
    <article
      style={{ ...styles.card, ...cardStyle }}
      role="button"
      tabIndex={0}
      onClick={() => onOpen?.(prop)}
      onKeyDown={(e) => {
        if (e.key === "Enter" || e.key === " ") {
          e.preventDefault();
          onOpen?.(prop);
        }
      }}
    >
      <div style={styles.compactCardTop}>
        {rank != null && <span style={styles.rankBadge}>#{rank}</span>}
        {resultBadge && (
          <span
            style={{
              fontSize: "10px",
              fontWeight: 800,
              padding: "2px 6px",
              borderRadius: "6px",
              border: `1px solid ${resultBadge.border}`,
              background: resultBadge.color,
              color: resultBadge.text,
              alignSelf: "flex-start",
            }}
            title={`Saved result: ${savedResult}`}
          >
            {resultBadge.label}
          </span>
        )}
        <PlayerImage prop={prop} />
        <div style={styles.cardInfo}>
          <div style={styles.cardTitleRow}>
            <div style={{ minWidth: 0 }}>
              <p style={styles.platform}>
                {prop.platform} · {displaySport(prop)}
              </p>
              <h3 style={styles.playerName}>{prop.playerName}</h3>
              {!compact && (
                <p style={styles.gameLine}>
                  {prop.team || "—"} vs {prop.opponent || "—"}
                </p>
              )}
            </div>
            <div style={styles.cardBadgeColumn}>
              <DataQualityBadge prop={prop} />
              <span style={tierStyle(isWatch ? "Risky" : tier)}>{isWatch ? "Watch" : tier}</span>
            </div>
          </div>
        </div>
      </div>
      <div style={styles.compactMetaRow}>
        <span style={styles.compactMetaItem}>
          <span style={styles.metaLabel}>Prop</span>
          <strong>{prop.statType}</strong>
        </span>
        <span style={styles.compactMetaItem}>
          <span style={styles.metaLabel}>Line</span>
          <strong>
            {formatNumber(prop.line)}
            {movementLabel ? <span style={{ marginLeft: "4px", color: "#7dd3fc", fontSize: "11px" }}>{movementLabel}</span> : null}
          </strong>
        </span>
        <span style={styles.compactMetaItem}>
          <span style={styles.metaLabel}>Lean</span>
          <strong style={styles.metaValueStrong}>{lean}</strong>
        </span>
        <span style={styles.compactMetaItem}>
          <span style={styles.metaLabel}>Conf</span>
          <strong style={styles.metaValueStrong}>{prop.confidenceScore ?? "—"}%</strong>
        </span>
        {prop.edgeScore != null && (
          <span style={styles.compactMetaItem}>
            <span style={styles.metaLabel}>Edge</span>
            <strong>{prop.edgeScore}</strong>
          </span>
        )}
      </div>
      {bookTag ? <p style={{ ...styles.compactFlags, margin: "4px 0 0", color: "#86efac" }}>{bookTag}</p> : null}
      {!compact && <p style={{ ...styles.compactFlags, margin: "4px 0 0" }}>{shortReason(prop)}</p>}
      <div style={styles.whyLink}>Why this pick?</div>
    </article>
  );
}
