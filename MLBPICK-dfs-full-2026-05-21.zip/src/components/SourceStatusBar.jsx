import { styles, sourceStatusStyle } from "../theme/styles.js";

function mapStatus(raw) {
  const s = String(raw || "Pending");
  if (["Full", "Partial", "Fallback", "Failed", "Cached", "Stale"].includes(s)) return s;
  if (s === "Connected") return "Full";
  if (/partial|fallback/i.test(s)) return "Partial";
  if (s === "Failed" || s === "Not Connected") return "Failed";
  if (s === "cached" || s === "fresh") return s === "fresh" ? "Full" : "Cached";
  if (s === "Pending") return "Failed";
  return s;
}

export default function SourceStatusBar({ sourceStatus = {}, sourceHealth = {}, cacheStatus = "", stale = false }) {
  const items = [
    ["PrizePicks", mapStatus(sourceStatus.PrizePicks)],
    ["Underdog", mapStatus(sourceStatus.Underdog)],
    ["Odds", mapStatus(sourceStatus["The Odds API"])],
    ["Injuries", mapStatus(sourceHealth.injuries || "Full")],
    ["NBA stats", mapStatus(sourceHealth.BallDontLie || "Full")],
    ["Soccer", mapStatus(sourceHealth["Soccer stats"] || "Full")],
    ["WNBA", mapStatus(sourceHealth["WNBA stats"] || "Full")],
  ];

  if (cacheStatus) {
    items.push(["Cache", stale ? "Stale" : cacheStatus === "fresh" ? "Full" : "Cached"]);
  }

  return (
    <section style={styles.sourceStatusBar} aria-label="Source status">
      {items.map(([name, status]) => (
        <div key={name} style={styles.sourceStatusItem}>
          <span style={styles.sourceName}>{name}</span>
          <span style={sourceStatusStyle(status)}>{status}</span>
        </div>
      ))}
    </section>
  );
}
