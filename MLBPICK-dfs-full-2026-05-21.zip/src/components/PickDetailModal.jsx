import { useEffect } from "react";
import { dataQualityBadge } from "../services/dataQuality.js";
import { buildPickExplanation, propPayoutLabel } from "../services/projectionEngine.js";
import DataQualityBadge from "./DataQualityBadge.jsx";
import PlayerImage from "./PlayerImage.jsx";
import { confidenceTier } from "../utils/propLabels.js";
import {
  dataSourcesUsed,
  displaySport,
  edgePercentForProp,
  formatDateTime,
  formatLeanSide,
  formatMaybeLine,
  formatNumber,
  formatPercent,
  formatSignedNumber,
  formatSignedPercent,
  keyStatsSummary,
  lineMovementStatusText,
  riskExplanation,
  usageContextForProp,
  warningFlags,
} from "../utils/pickAnalysis.js";
import { styles, riskStyle, tierStyle } from "../theme/styles.js";

const NO_EDGE_MESSAGE = "No betting edge detected. More data needed before this becomes a confident pick.";
const STREAK_WARNING = "Low multiplier does not guarantee the pick will hit. Verify before adding to streak.";

function Metric({ label, value, strong = false }) {
  return (
    <div style={styles.metric}>
      <span style={styles.metricLabel}>{label}</span>
      <strong style={strong ? styles.metricValueStrong : styles.metricValue}>{value}</strong>
    </div>
  );
}

export default function PickDetailModal({ prop, onClose, onUpdateResult }) {
  const lean = formatLeanSide(prop.bestPick || prop.side || "Watch");
  const isWatchlist = prop.recommendationStatus === "watchlist";
  const tier = confidenceTier(prop);
  const badge = prop.dataQualityBadge || dataQualityBadge(prop);
  const explanation = buildPickExplanation({
    ...prop,
    dataQualityBadge: badge,
    dataSources: prop.dataSources || dataSourcesUsed(prop),
  });

  useEffect(() => {
    function handleKeyDown(event) {
      if (event.key === "Escape") onClose?.();
    }
    window.addEventListener("keydown", handleKeyDown);
    return () => window.removeEventListener("keydown", handleKeyDown);
  }, [onClose]);

  return (
    <div style={styles.modalBackdrop} role="presentation" onClick={onClose}>
      <section
        style={styles.modalPanel}
        role="dialog"
        aria-modal="true"
        aria-label={`${prop.playerName} evaluation`}
        onClick={(event) => event.stopPropagation()}
      >
        <div style={styles.modalHeader}>
          <div style={styles.modalPlayer}>
            <PlayerImage prop={prop} large />
            <div>
              <p style={styles.platform}>{prop.platform}</p>
              <h2 style={styles.modalTitle}>{prop.playerName}</h2>
              <p style={styles.gameLine}>
                {displaySport(prop)} · {prop.team || "—"} vs {prop.opponent || "—"}
              </p>
            </div>
          </div>
          <button type="button" style={styles.closeButton} onClick={onClose} aria-label="Close evaluation">
            ✕ Close
          </button>
        </div>

        <div style={styles.tagRow}>
          <span style={tierStyle(tier)}>{tier}</span>
          <span style={riskStyle(prop.riskLevel)}>{prop.riskLevel || "Medium"}</span>
          <DataQualityBadge badge={badge} />
          {(prop.payoutLabel || propPayoutLabel(prop)) !== "standard" && (
            <span style={styles.valueTag}>{prop.payoutLabel || propPayoutLabel(prop)}</span>
          )}
        </div>

        <div style={styles.modalGrid}>
          <Metric label="Prop" value={prop.statType} />
          <Metric label="Line" value={formatNumber(prop.line)} strong />
          <Metric label="Lean" value={isWatchlist ? "Watch" : lean} strong />
          <Metric label="Confidence" value={`${prop.confidenceScore ?? "—"}%`} strong />
          <Metric label="Edge score" value={prop.edgeScore ?? prop.edgeRating ?? "—"} strong />
          <Metric label="Projection" value={prop.projection == null ? "Needs stats" : formatNumber(prop.projection)} />
          <Metric label="Stat edge" value={formatSignedNumber(prop.edge)} />
          <Metric label="Edge %" value={formatSignedPercent(edgePercentForProp(prop) != null ? edgePercentForProp(prop) / 100 : null)} />
          <Metric label="Model prob" value={formatPercent(prop.modelProbability)} />
          <Metric label="EV" value={formatSignedPercent(prop.expectedValue)} />
          <Metric label="L5 / L10" value={`${formatPercent(prop.last5HitRate)} / ${formatPercent(prop.last10HitRate || prop.recentHitRate)}`} />
          <Metric label="Matchup" value={prop.matchupRating || "Neutral"} />
          <Metric label="Injury/news" value={prop.injuryRisk || "Low"} />
          <Metric label="Opening line" value={formatMaybeLine(prop.lineMovement?.openingLine)} />
          <Metric label="Current line" value={formatMaybeLine(prop.lineMovement?.currentLine ?? prop.line)} />
          <Metric label="Movement" value={lineMovementStatusText(prop)} />
          <Metric label="Sources" value={dataSourcesUsed(prop).join(", ") || "—"} />
          <Metric label="Risks" value={riskExplanation(prop)} />
          <Metric label="Flags" value={warningFlags(prop).join(", ") || "None"} />
          <Metric label="Start" value={formatDateTime(prop.startTime)} />
        </div>

        {(prop.lineComparison || prop.sportsbookComparison) && (
          <div style={styles.comparisonBox}>
            {prop.lineComparison && <span>PP: {formatMaybeLine(prop.lineComparison.prizePicksLine)}</span>}
            {prop.lineComparison && <span>UD: {formatMaybeLine(prop.lineComparison.underdogLine)}</span>}
            {prop.sportsbookComparison && <span>Books avg: {formatMaybeLine(prop.sportsbookComparison.marketAverageLine)}</span>}
          </div>
        )}

        <div style={styles.explanationSections}>
          {explanation.map((section) => (
            <div key={section.title} style={styles.explanationBlock}>
              <strong>{section.title}</strong>
              <ul style={styles.explanationList}>
                {section.lines.map((line) => (
                  <li key={line}>{line}</li>
                ))}
              </ul>
            </div>
          ))}
        </div>

        <div style={styles.evaluationText}>
          <strong>Why this pick</strong>
          <p>{keyStatsSummary(prop)}</p>
          <p>{usageContextForProp(prop)}</p>
          <p>{isWatchlist ? prop.watchlistMessage || NO_EDGE_MESSAGE : prop.reasoningSummary}</p>
          {prop.side && <p>{STREAK_WARNING}</p>}
        </div>

        {onUpdateResult && (
          <div style={{ ...styles.resultButtons, marginTop: "12px" }}>
            {["Win", "Loss", "Push", "Pending", "Manual"].map((result) => (
              <button
                key={result}
                type="button"
                style={(prop.resultStatus || prop.finalResult) === result ? styles.resultButtonActive : styles.resultButton}
                onClick={() => onUpdateResult(prop.id, result)}
              >
                {result}
              </button>
            ))}
          </div>
        )}
      </section>
    </div>
  );
}
