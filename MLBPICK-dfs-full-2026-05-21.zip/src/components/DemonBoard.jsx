import PlayerPropCard from "./PlayerPropCard.jsx";
import { computeRankScore } from "../services/projectionEngine.js";
import { isDemonProp } from "../utils/propLabels.js";
import { styles } from "../theme/styles.js";

function EmptyState({ text }) {
  return <div style={styles.emptyState}>{text}</div>;
}

export default function DemonBoard({ picks = [], loading, onOpen }) {
  const demons = [...picks]
    .filter(isDemonProp)
    .sort((a, b) => computeRankScore(b) - computeRankScore(a))
    .slice(0, 6);

  return (
    <section style={styles.section}>
      <div style={styles.sectionHeading}>
        <div>
          <p style={styles.eyebrow}>Verified Demon</p>
          <h2 style={styles.sectionTitle}>Demon Board</h2>
        </div>
        <p style={styles.countPill}>{demons.length} picks</p>
      </div>
      {loading ? (
        <EmptyState text="Loading Demon lines…" />
      ) : demons.length === 0 ? (
        <EmptyState text="No verified Demon props available right now." />
      ) : (
        <>
          <div style={styles.cardGrid}>
            {demons.map((prop) => (
              <PlayerPropCard key={prop.id} prop={prop} onOpen={onOpen} compact cardStyle={styles.demonCard} />
            ))}
          </div>
          <p style={styles.compactFlags}>Higher payout means higher variance.</p>
        </>
      )}
    </section>
  );
}
