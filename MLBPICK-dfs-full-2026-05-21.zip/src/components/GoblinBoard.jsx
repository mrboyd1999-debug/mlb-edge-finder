import PlayerPropCard from "./PlayerPropCard.jsx";
import { computeRankScore } from "../services/projectionEngine.js";
import { isGoblinProp } from "../utils/propLabels.js";
import { styles } from "../theme/styles.js";

function EmptyState({ text }) {
  return <div style={styles.emptyState}>{text}</div>;
}

export default function GoblinBoard({ picks = [], loading, onOpen }) {
  const goblins = [...picks]
    .filter(isGoblinProp)
    .sort((a, b) => computeRankScore(b) - computeRankScore(a))
    .slice(0, 6);

  return (
    <section style={styles.section}>
      <div style={styles.sectionHeading}>
        <div>
          <p style={styles.eyebrow}>Verified Goblin</p>
          <h2 style={styles.sectionTitle}>Goblin Board</h2>
        </div>
        <p style={styles.countPill}>{goblins.length} picks</p>
      </div>
      {loading ? (
        <EmptyState text="Loading Goblin lines…" />
      ) : goblins.length === 0 ? (
        <EmptyState text="No verified Goblin props available right now." />
      ) : (
        <>
          <div style={styles.cardGrid}>
            {goblins.map((prop) => (
              <PlayerPropCard key={prop.id} prop={prop} onOpen={onOpen} compact cardStyle={styles.goblinCard} />
            ))}
          </div>
          <p style={styles.compactFlags}>Lower payout does not guarantee a hit.</p>
        </>
      )}
    </section>
  );
}
