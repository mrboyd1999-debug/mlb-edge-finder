import { defineConfig } from "vite";
import react from "@vitejs/plugin-react";

const proxyCache = new Map();
const PROXY_CACHE_MS = 60 * 1000;
const PROXY_STALE_MS = 10 * 60 * 1000;
const BALLDONTLIE_API_KEY = process.env.BALLDONTLIE_API_KEY || process.env.VITE_BALLDONTLIE_API_KEY || "";
const API_FOOTBALL_KEY = process.env.API_FOOTBALL_KEY || process.env.VITE_API_FOOTBALL_KEY || "";
const ODDS_API_KEY = process.env.ODDS_API_KEY || process.env.VITE_ODDS_API_KEY || "";

export default defineConfig({
  plugins: [react(), dfsApiProxy()],
});

function dfsApiProxy() {
  return {
    name: "dfs-api-proxy",
    configureServer(server) {
      server.middlewares.use(async (req, res, next) => {
        const requestUrl = req.url || "";
        const isPrizePicks = requestUrl.startsWith("/api/prizepicks");
        const isUnderdog = requestUrl.startsWith("/api/underdog");
        const isSportsbookOdds = requestUrl.startsWith("/api/sportsbookOdds");
        const isBallDontLie = requestUrl.startsWith("/api/balldontlie");
        const isApiFootball = requestUrl.startsWith("/api/api-football");

        if (!isPrizePicks && !isUnderdog && !isSportsbookOdds && !isBallDontLie && !isApiFootball) {
          next();
          return;
        }

        const targetBase = proxyTargetBase({ isPrizePicks, isUnderdog, isSportsbookOdds, isBallDontLie, isApiFootball });
        const targetPath = proxyTargetPath(requestUrl, { isPrizePicks, isUnderdog, isSportsbookOdds, isBallDontLie, isApiFootball });
        const upstreamUrl = new URL(targetPath || "/", targetBase);
        if (isSportsbookOdds && ODDS_API_KEY && !upstreamUrl.searchParams.has("apiKey")) {
          upstreamUrl.searchParams.set("apiKey", ODDS_API_KEY);
        }
        const cacheKey = upstreamUrl.toString();
        const cached = proxyCache.get(cacheKey);

        if (cached && Date.now() - cached.createdAt < PROXY_CACHE_MS) {
          sendProxyResponse(res, 200, cached.contentType, cached.body);
          return;
        }

        try {
          const upstream = await fetch(upstreamUrl, {
            headers: proxyHeaders({ isPrizePicks, isUnderdog, isSportsbookOdds, isBallDontLie, isApiFootball }),
          });
          const rawBody = Buffer.from(await upstream.arrayBuffer());
          const contentType = upstream.headers.get("content-type") || "application/json";

          console.info("[DFS proxy] upstream", {
            requestUrl,
            upstreamUrl: upstreamUrl.toString().replace(/apiKey=[^&]+/, "apiKey=***"),
            status: upstream.status,
            contentType,
          });

          const proxyResponse = jsonProxyResponse({
            body: rawBody,
            contentType,
            upstreamStatus: upstream.status,
            source: proxySourceName({ isPrizePicks, isUnderdog, isSportsbookOdds, isBallDontLie, isApiFootball }),
            wrap: isPrizePicks || isUnderdog,
          });

          if (upstream.ok && proxyResponse.ok) {
            proxyCache.set(cacheKey, { body: proxyResponse.body, contentType: proxyResponse.contentType, createdAt: Date.now() });
          } else if (cached && Date.now() - cached.createdAt < PROXY_STALE_MS) {
            sendProxyResponse(res, 200, cached.contentType, cached.body);
            return;
          }

          sendProxyResponse(res, proxyResponse.statusCode, proxyResponse.contentType, proxyResponse.body);
        } catch (error) {
          if (cached && Date.now() - cached.createdAt < PROXY_STALE_MS) {
            sendProxyResponse(res, 200, cached.contentType, cached.body);
            return;
          }

          res.statusCode = 502;
          res.setHeader("content-type", "application/json");
          res.end(JSON.stringify({ ok: false, error: error.message || "DFS proxy failed", props: [] }));
        }
      });
    },
  };
}

function jsonProxyResponse({ body, contentType, upstreamStatus, source, wrap }) {
  const text = body.toString("utf8");
  const trimmed = text.trim();
  const invalidJson =
    trimmed.startsWith("<") ||
    /^export\s+default\b/.test(trimmed) ||
    trimmed.includes("export default async function");
  let parsed = null;
  let parseError = "";

  if (!invalidJson && trimmed) {
    try {
      parsed = JSON.parse(trimmed);
    } catch (error) {
      parseError = error.message || "Invalid JSON";
    }
  }

  if (!upstreamStatus || upstreamStatus < 200 || upstreamStatus >= 300 || invalidJson || parseError) {
    const message = invalidJson || parseError
      ? `${source} returned non-JSON response`
      : `${source} returned status ${upstreamStatus}`;
    const payload = {
      ok: false,
      source,
      error: message,
      message,
      status: upstreamStatus,
      props: [],
      data: [],
      preview: text.slice(0, 300),
    };
    return {
      ok: false,
      statusCode: 200,
      contentType: "application/json",
      body: Buffer.from(JSON.stringify(payload)),
    };
  }

  if (wrap) {
    const payload = {
      ok: true,
      error: false,
      source,
      data: parsed,
      props: Array.isArray(parsed) ? parsed : [],
    };
    return {
      ok: true,
      statusCode: 200,
      contentType: "application/json",
      body: Buffer.from(JSON.stringify(payload)),
    };
  }

  return {
    ok: true,
    statusCode: 200,
    contentType: contentType.includes("json") ? contentType : "application/json",
    body,
  };
}

function proxySourceName({ isPrizePicks, isUnderdog, isSportsbookOdds, isBallDontLie, isApiFootball }) {
  if (isPrizePicks) return "PrizePicks";
  if (isUnderdog) return "Underdog";
  if (isSportsbookOdds) return "The Odds API";
  if (isBallDontLie) return "BallDontLie";
  if (isApiFootball) return "API-Football";
  return "API";
}

function proxyTargetBase({ isPrizePicks, isUnderdog, isSportsbookOdds, isBallDontLie }) {
  if (isPrizePicks) return "https://api.prizepicks.com";
  if (isUnderdog) return "https://api.underdogfantasy.com";
  if (isSportsbookOdds) return "https://api.the-odds-api.com";
  if (isBallDontLie) return "https://api.balldontlie.io";
  return "https://v3.football.api-sports.io";
}

function proxyTargetPath(requestUrl, flags) {
  const parsed = new URL(requestUrl, "http://localhost");
  if (flags.isPrizePicks) {
    const leagueId = parsed.searchParams.get("league_id");
    if (leagueId) {
      return `/projections?league_id=${encodeURIComponent(leagueId)}&per_page=250&single_stat=true&game_mode=pickem`;
    }
    return `/projections?per_page=250&single_stat=true&game_mode=pickem`;
  }
  if (flags.isUnderdog) return `/beta/v3/over_under_lines`;
  if (flags.isSportsbookOdds) {
    const path = parsed.searchParams.get("path") || "/";
    parsed.searchParams.delete("path");
    const query = parsed.searchParams.toString();
    return `${path}${query ? `?${query}` : ""}`;
  }
  return requestUrl.replace(proxyPrefix(flags), "");
}

function proxyPrefix({ isBallDontLie }) {
  if (isBallDontLie) return "/api/balldontlie";
  return "/api/api-football";
}

function proxyHeaders({ isPrizePicks, isUnderdog, isSportsbookOdds, isBallDontLie, isApiFootball }) {
  if (isPrizePicks) return prizePicksHeaders();
  if (isUnderdog) return underdogHeaders();
  if (isSportsbookOdds) return { accept: "application/json" };
  if (isBallDontLie) return ballDontLieHeaders();
  if (isApiFootball) return apiFootballHeaders();
  return { accept: "application/json" };
}

function sendProxyResponse(res, statusCode, contentType, body) {
  res.statusCode = statusCode;
  res.setHeader("content-type", contentType);
  res.setHeader("cache-control", "no-store");
  res.end(body);
}

function prizePicksHeaders() {
  return {
    accept: "application/json",
    origin: "https://app.prizepicks.com",
    referer: "https://app.prizepicks.com/",
    "user-agent":
      "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/125 Safari/537.36",
  };
}

function underdogHeaders() {
  return {
    accept: "application/json",
    origin: "https://underdogfantasy.com",
    referer: "https://underdogfantasy.com/",
    "user-agent":
      "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/125 Safari/537.36",
  };
}

function ballDontLieHeaders() {
  return {
    accept: "application/json",
    ...(BALLDONTLIE_API_KEY ? { Authorization: BALLDONTLIE_API_KEY } : {}),
  };
}

function apiFootballHeaders() {
  return {
    accept: "application/json",
    ...(API_FOOTBALL_KEY ? { "x-apisports-key": API_FOOTBALL_KEY } : {}),
  };
}
